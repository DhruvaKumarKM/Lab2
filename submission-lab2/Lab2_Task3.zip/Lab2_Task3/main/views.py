from django.utils.translation import gettext_lazy as _
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.utils.translation import activate
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView


@login_required
def dashboard(request):
    
    if request.user.is_authenticated:
        user_language = request.session.get(settings.LANGUAGE_COOKIE_NAME, 'en')  # Default to English
        activate(user_language)

    context = {
        'welcome_message': _('Welcome to your Dashboard!'),
    }
    return render(request, 'dashboard.html', context)



def switch_language(request, language_code):
    
    # Activate the new language
    activate(language_code)
    # Set the language in the session
    request.session[settings.LANGUAGE_COOKIE_NAME] = language_code

    # If the user is logged in, update their preferred language in the profile
    if request.user.is_authenticated and hasattr(request.user, 'userprofile'):
        request.user.userprofile.preferred_language = language_code
        request.user.userprofile.save()

    # Redirect to the previous page or home
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


class CustomLoginView(LoginView):
    
    template_name = 'login.html'

    def form_valid(self, form):
        # Setting the user's preferred language after login
        user_language = self.request.session.get(settings.LANGUAGE_COOKIE_NAME, 'en')
        activate(user_language)
        self.request.session[settings.LANGUAGE_COOKIE_NAME] = user_language
        return super().form_valid(form)
