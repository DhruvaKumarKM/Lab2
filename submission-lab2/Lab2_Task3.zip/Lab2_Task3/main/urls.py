from django.contrib.auth.views import LogoutView
from django.urls import path,include
from .views import dashboard, switch_language, CustomLoginView

urlpatterns = [
    path('', dashboard, name='dashboard'),
    path('switch_language/<str:language_code>/', switch_language, name='switch_language'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path("accounts/", include("django.contrib.auth.urls")),
]

