from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import UserProfile, Company
from .forms import UserProfileForm

def home(request):
    context ={
        'title':'Home page'
    }
    return render(request, 'home.html', context)

@login_required
def profile_list(request):
    profiles = UserProfile.objects.filter(user=request.user)
    return render(request, 'profile_list.html', {'profiles': profiles})

@login_required
def add_profile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            return redirect('profile_list')
    else:
        form = UserProfileForm()

    return render(request, 'add_profile.html', {'form': form})
