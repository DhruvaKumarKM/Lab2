from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm, EmailLoginForm, CustomPasswordChangeForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    context ={
        'title':'Registration',
        'form': form,
    }
    return render(request, 'register.html', context)


def user_login(request):
    if request.method == "POST":
        form = EmailLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, username=email, password=password)
            if user:
                login(request, user)
                return redirect('home')
    else:
        form = EmailLoginForm()
    context ={
        'title':'Login',
        'form': form,
    }
    return render(request, 'login.html', context)


def user_logout(request):
    logout(request)
    return redirect('login')


@login_required
def change_password(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            # user = request.user
            # user.set_password(form.cleaned_data['new_password1'])
            # user.save()
            form.save()
            logout(request)

            return redirect('login')  
    else:
        form = CustomPasswordChangeForm(request.user)

    context = {
        'form': form,
        'title': 'Change Password',
    }
    return render(request, 'change_password.html', context)


