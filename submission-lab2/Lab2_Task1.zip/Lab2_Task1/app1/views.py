from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def calendar(request):
    return render(request, 'apps-calendar.html')

def dashboard(request):
    return render(request, 'charts-apex.html')

def calendar(request):
    return render(request,'apps-calendar.html')

def charts_apex(request):
    return render(request,'charts-apex.html')


