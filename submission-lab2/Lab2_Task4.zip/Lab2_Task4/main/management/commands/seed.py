from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from main.models import Company, Product

class Command(BaseCommand):
    help = "Seed the database with initial data"

    def handle(self, *args, **kwargs):
    
        if not User.objects.filter(username="system").exists():
            User.objects.create_superuser(username="system", password="password", email="system@example.com")
            self.stdout.write(self.style.SUCCESS('Created system user'))

        company, created = Company.objects.get_or_create(name="HelloWorld Company")
        if created:
            self.stdout.write(self.style.SUCCESS('Created HelloWorld Company'))

        if not Product.objects.filter(name="Sample Product").exists():
            Product.objects.create(name="Sample Product", price=99.99, company=company)
            self.stdout.write(self.style.SUCCESS('Created Sample Product'))
